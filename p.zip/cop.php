<?php
function copyss(){
echo '© 2014. All rights reserved.';
}
?>